﻿using UnityEngine;
using System.Collections;

public class GameInfo  {

    public static float coinNum;
    public static float mi;

    public static void RestGameInfo() 
    {
        coinNum = 0;
        mi = 0;

    }
}
